# Upgrade Plan: Legacy Change Assistant (20260929114334)

- **Generated**: 2026-09-29 11:43
- **HEAD Branch**: N/A
- **HEAD Commit ID**: N/A

## Available Tools

**JDKs**
- JDK 21: not available (baseline will be skipped)
- JDK 25: **<TO_BE_INSTALLED>** (required for upgrade compilation and tests)

**Build Tools**
- Maven: **<TO_BE_INSTALLED>** (install Maven 3.9.15 for local validation)
- Maven Wrapper: not present

## Guidelines

- Upgrade only the backend Java runtime to the latest LTS, Java 25.
- Preserve current application behavior and existing database access/security boundaries.

> Note: You can add any specific guidelines or constraints for the upgrade process here if needed, bullet points are preferred.

## Options

- Working branch: N/A (workspace is not a git repository; changes will not be version-controlled)
- Run tests before and after the upgrade: true
- Execution mode: auto-execution

## Upgrade Goals

- Java runtime: 25 (latest LTS as of 2026-09-29)

## Technology Stack

| Technology/Dependency | Current | Min Compatible Version | Why Incompatible |
| --------------------- | ------- | ---------------------- | ---------------- |
| Java | 21 | 25 | User requested latest LTS runtime |
| Spring Boot | 3.5.6 | 3.5.6 | No framework upgrade requested; current line supports Java 25 |
| Maven Docker build image | maven:3.9-eclipse-temurin-21 | maven:3.9-eclipse-temurin-25 | Build container must compile with target JDK |
| Eclipse Temurin runtime image | eclipse-temurin:21-jre | eclipse-temurin:25-jre | Runtime container must use target JDK |
| Maven (local validation) | Not installed | 3.9.15 | Required for local build and test validation |

## Derived Upgrades

- Change the Maven compiler target and both backend Docker image tags to Java 25 so the build and runtime use the requested LTS consistently.
- No Spring Boot, plugin, or source-code upgrade is required for the Java target change.

## Impact Analysis

### Dependency Changes

| File | Dependency | Current | Action | Target | Reason |
|------|-----------|---------|--------|--------|--------|
| backend/pom.xml | java.version | 21 | upgrade | 25 | Set Maven compilation target to the requested LTS |

### Source Code Changes

No Java source changes are indicated by the compatibility scan. No internal JDK APIs, removed modules, or Java 25-incompatible constructs were found.

### Configuration Changes

No application configuration changes are required.

### CI/CD Changes

No CI/CD files with Java version pins were found.

### Risks & Warnings

- **Container image availability/buildability**: Java 25 image tags must resolve when the Docker image is built. **Mitigation**: use the maintained Maven/Temurin image tags and verify the Maven build with a local Java 25 JDK; attempt a Docker build if Docker is available.
- **Java 21 baseline unavailable**: local machine has JDK 17 and 24, but not Java 21. **Mitigation**: skip the baseline and use Java 25 compilation plus the complete post-upgrade test suite as validation.
- **Version control unavailable**: workspace is not a Git repository. **Mitigation**: leave changes in the workspace and record this limitation; do not initialize a repository.

## Upgrade Steps

- Step 1: Setup Environment
  - **Rationale**: Java 25 and Maven are required to compile and test the upgraded backend locally.
  - **Changes to Make**: Install JDK 25 and Maven 3.9.15.
  - **Verification**: Confirm JDK 25 with the JDK listing tool and Maven installation path/version.
- Step 2: Setup Baseline
  - **Rationale**: Capture pre-upgrade behavior when the current JDK is available.
  - **Changes to Make**: None; skip because JDK 21 is unavailable.
  - **Verification**: Record baseline as skipped; do not run the build with a different JDK.
- Step 3: Upgrade Backend Runtime to Java 25
  - **Rationale**: Align Maven compilation and Docker build/runtime environments with the requested LTS.
  - **Changes to Make**: Apply the Dependency Changes and update both Java image tags in the backend Dockerfile, as detailed above.
  - **Verification**: From backend, run `mvn clean test-compile -q` using JDK 25; compilation succeeds.
- Step 4: CVE Validation & Fix
  - **Rationale**: Check direct backend dependencies for known vulnerabilities after dependency resolution.
  - **Changes to Make**: Scan resolved direct dependencies; apply only necessary patched-version changes if vulnerabilities are reported.
  - **Verification**: Compile after any fixes and rescan; no fixable reported CVEs remain.
- Step 5: Final Validation
  - **Rationale**: Confirm the target version is configured and all backend tests pass.
  - **Changes to Make**: None unless validation exposes a target-related defect; resolve any failures.
  - **Verification**: From backend, run `mvn clean test -q` using JDK 25; all tests pass. Confirm Docker image tags use Java 25 and build the backend image if Docker is available.
